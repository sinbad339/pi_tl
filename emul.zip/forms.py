#-------------------------------------------------------------------------------
# Name:        forms
# Purpose:
#
# Author:      jdilorenzo
#
# Created:     11/09/2018
# Copyright:   (c) jdilorenzo 2018
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from flask_wtf import Form
from wtforms import TextField, IntegerField, TextAreaField, SubmitField, RadioField, SelectField

from wtforms import validators, ValidationError

class ContactForm(Form):
    name = TextField("Name Of Student",[validators.Required("Please enter your name.")])
    Gender = RadioField('Gender', choices = [('M','Male'),('F','Female')])
    Address = TextAreaField("Address")

    email = TextField("Email",[validators.Required("Please enter your email address."), validators.Email("Please enter your email address.")])

    Age = IntegerField("age")
    language = SelectField('Languages', choices = [('cpp', 'C++'), ('py', 'Python')])
    submit = SubmitField("Send")

class ConfigureForm(Form):
    mode = RadioField('Mode', choices = [('a','Traffic Light'),('b','Parking'),('c','Sunday at the Speedway'),('d','Test')])
    tl_rate = TextField("Traffic Light Rate",[validators.Required("Requuired Field")])
    g2y_dist = TextField("Green <=> Yellow Distance (inches)",[validators.Required("Required Field")])
    y2r_dist = TextField("Yellow <=> Red Distance (inches)  ",[validators.Required("Required Field")])
    hyst = TextField("Hysteresis (inches)                   ",[validators.Required("Required Field")])
    sats_rate = TextField("Rate (0 - 1.0)",[validators.Required("Required Field")])
    submit = SubmitField("Send")
