#-------------------------------------------------------------------------------
# Name:        TLConfig
# Purpose:
#
# Author:      jdilorenzo
#
# Created:     11/09/2018
# Copyright:   (c) jdilorenzo 2018
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from flask import Flask, render_template, request, flash
from forms import ConfigureForm
import csv

app = Flask(__name__)
app.secret_key = '1930FordModelA,201'

@app.route('/', methods = ['GET', 'POST'])
def configure():
    form = ConfigureForm()

    if request.method == 'POST':
        print 'This was a post'
        if form.validate() == False:
            flash('All fields are required.')
            return render_template('t-config.html', form = form)
        else:
            return render_template('success.html')

    elif request.method == 'GET':
        print 'This was a get'
        form.mode.data = 'a'
        form.tl_rate.data = rd_tuple[1][1]
        form.g2y_dist.data = rd_tuple[2][1]
        form.y2r_dist.data = rd_tuple[3][1]
        form.hyst.data = rd_tuple[4][1]
        form.sats_rate.data = rd_tuple[5][1]

        return render_template('t-config.html', form = form)

if __name__ == '__main__':
    csvfile = open('tl_cfg.csv', 'r')
    readCSV = csv.reader(csvfile, delimiter=',')
    rd_tuple = []

    for row in readCSV:
        rd_tuple.append(row)

    mode = rd_tuple[0][1]
    tl_distance = rd_tuple[1][1]
    GreenYellowDist = rd_tuple[2][1]
    YellowRedDist = rd_tuple[3][1]
    histersis = rd_tuple[4][1]
    SpeedRate = rd_tuple[5][1]
    ForceRed = rd_tuple[6][1]
    ForceYellow = rd_tuple[7][1]
    ForceGreen = rd_tuple[8][1]

    app.run(host='0.0.0.0', port=80, debug=True)
